<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>

    {{--  Bootstrap & Icons  --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    {{--  ======  New Footer Styles V2 ====== --}}
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }
        .container.mt-5 {
            flex-grow: 1;
        }

        /* ---------- Sleek Footer V2 ---------- */
        .sleek-footer {
            position: relative;
            margin-top: 5rem; /* Ensure space above footer */
            padding: 2rem 0; /* Vertical padding for the main footer area */
            background-color: var(--footer-bg-color, #2c3e50); /* Base color, overridden by profile */
            color: var(--footer-text-color, #ffffff); /* Base text color */
            border-top: 4px solid var(--footer-accent-color, #4e6a85); /* Accent border, slightly darker/lighter */
        }

        .sleek-footer .footer-content-wrapper {
            position: relative;
            max-width: 1140px; /* Standard container width */
            margin: 0 auto; /* Center the wrapper */
            padding: 2rem 1.5rem; /* Padding inside the wrapper */
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 15px; /* Rounded corners for the card */
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.15); /* Softer shadow */
            border: 1px solid rgba(255, 255, 255, 0.18); /* Subtle border for glass effect */
        }

        .sleek-footer .profile-logo img {
            width: 90px;
            height: 90px;
            border-radius: 50%; /* Circular logo */
            border: 4px solid var(--footer-accent-color, #ffffff);
            object-fit: cover;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        
        .sleek-footer .profile-logo-placeholder {
            width:90px; 
            height:90px; 
            border-radius:50%; 
            background:var(--footer-accent-color);
            display:flex; 
            align-items:center; 
            justify-content:center; 
            margin: 0 auto; /* Center placeholder on mobile */
            border: 4px solid var(--footer-accent-color, #ffffff);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        .sleek-footer .profile-logo-placeholder i {
             color: var(--footer-bg-color);
        }

        .sleek-footer .profile-name {
            font-size: 1.85rem;
            font-weight: 700; /* Bolder name */
            margin-bottom: 0.85rem;
            letter-spacing: 0.5px;
        }

        .sleek-footer .profile-details p {
            font-size: 1.05rem; /* Slightly larger detail text */
            margin-bottom: 0.6rem;
            display: flex;
            align-items: center;
            line-height: 1.6;
        }

        .sleek-footer .profile-details i {
            margin-right: 1rem; /* More space for icon */
            font-size: 1.25rem;
            width: 22px; /* Fixed width for icons */
            text-align: center;
            color: var(--footer-accent-color, #ffffff); /* Icon color tied to accent */
        }

        .sleek-footer .profile-details a {
            color: var(--footer-text-color, #ffffff);
            text-decoration: none; /* No underline by default */
            word-break: break-all;
            font-weight: 500; /* Slightly bolder links */
        }

        .sleek-footer .profile-details a:hover {
            text-decoration: underline; /* Underline on hover */
            opacity: 0.85;
        }

        /* Responsive adjustments */
        @media (max-width: 767.98px) {
            .sleek-footer .footer-content-wrapper {
                padding: 1.5rem 1rem;
            }
            .sleek-footer .profile-logo,
            .sleek-footer .profile-logo-placeholder {
                margin-left: auto;
                margin-right: auto;
                margin-bottom: 1.2rem;
            }
            .sleek-footer .profile-name {
                text-align: center;
                font-size: 1.6rem;
            }
            .sleek-footer .profile-details p {
                font-size: 1rem;
                justify-content: flex-start; /* Align text to start on mobile for readability */
            }
            .sleek-footer .profile-details i {
                font-size: 1.15rem;
            }
        }
    </style>
</head>
<body>

    {{-- ================= Certificate Section ================= --}}
    <div class="container mt-5">
        <div class="row">
            <div class="col-12">

                {{--  Logo & Name  --}}
                <div class="d-flex align-items-center mb-2">
                    <img src="{{ asset($certificate->logo) }}" style="height:61px;" alt="">
                    <span class="ms-3 fw-bold" style="font-size:20px;">{{ $certificate->name }}</span>
                </div>

                {{--  Description  --}}
                {!! $certificate->description !!}

                {{--  Certificate Image  --}}
                @if($certificate->certificate_logo)
                    <img class="mt-4 mb-3" src="{{ asset($certificate->certificate_logo) }}" style="max-width:100%;">
                @elseif($certificate->certificate)
                    <img class="mt-4 mb-3" src="{{ asset($certificate->certificate) }}" style="max-width:100%;">
                @endif

                {{--  Course Outline  --}}
                {!! $certificate->course_outline !!}

                {{--  Attachments  --}}
                @if($certificate->attachments)
                    <br>
                    @foreach (unserialize($certificate->attachments) as $key => $attach)
                        <span class="badge bg-dark rounded-pill px-3 py-2 mb-2">
                            Transcript / Grade record {{ $key+1 }}
                        </span>
                        <a class="ms-2" target="_blank" href="{{ asset($attach) }}">
                            <i class="bi bi-eye" style="font-size:1.5rem;"></i>
                        </a>
                    @endforeach
                    <br><br>
                @endif

            </div>
        </div>
    </div>

    {{-- ================= Sleek Glass Footer V2 ================= --}}
    @php
        $footerProfile = Auth::check()
            ? \App\Models\Profile::where('user_id', Auth::id())->first()
            : null;

        // Helper to determine text and accent colors based on background brightness
        function getBrightness($hexColor) {
            $hex = str_replace('#', '', $hexColor);
            if (strlen($hex) == 3) {
                $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
            }
            if (strlen($hex) != 6) return 100; // Default to a mid-range brightness if hex is invalid
            
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
            return (($r * 0.299) + ($g * 0.587) + ($b * 0.114));
        }

        $footerBgColor = $footerProfile && $footerProfile->color ? $footerProfile->color : '#2c3e50';
        $brightness = getBrightness($footerBgColor);

        $footerTextColor = $brightness > 150 ? '#212529' : '#f8f9fa'; // Bootstrap dark and light text colors
        // For accent, pick a color that contrasts with the background but is harmonious
        if ($brightness > 200) { // Very light background
            $footerAccentColor = '#6c757d'; // Bootstrap secondary
        } elseif ($brightness > 120) { // Medium background
            $footerAccentColor = $brightness > 150 ? '#495057' : '#dee2e6'; // Bootstrap gray or light gray
        } else { // Dark background
            $footerAccentColor = '#adb5bd'; // Bootstrap gray-500
        }

    @endphp

    @if($footerProfile)
    <footer class="sleek-footer" style="
        --footer-bg-color: {{ $footerBgColor }};
        --footer-text-color: {{ $footerTextColor }};
        --footer-accent-color: {{ $footerAccentColor }};
    ">
        <div class="footer-content-wrapper">
            <div class="container">
                <div class="row align-items-center gy-4">
                    <div class="col-md-3 text-center text-md-start profile-logo">
                        @if($footerProfile->logo)
                            <img src="{{ $footerProfile->logo }}" alt="{{ $footerProfile->name }}'s Logo">
                        @else
                            <div class="profile-logo-placeholder">
                                <i class="fas fa-user fa-3x"></i>
                            </div>
                        @endif
                    </div>
                    <div class="col-md-9 profile-details text-center text-md-start">
                        <h3 class="profile-name">{{ $footerProfile->name }}</h3>
                        @if($footerProfile->phone)
                        <p><i class="fas fa-phone-alt"></i> <span>{{ $footerProfile->phone }}</span></p>
                        @endif
                        @if($footerProfile->address)
                        <p><i class="fas fa-map-marker-alt"></i> <span>{{ $footerProfile->address }}</span></p>
                        @endif
                        @if($footerProfile->weblink)
                        <p><i class="fas fa-link"></i> <a href="{{ $footerProfile->weblink }}" target="_blank">{{ $footerProfile->weblink }}</a></p>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </footer>
    @endif


    <script src="{{ asset('back/js/core/jquery.min.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{ asset('back/js/core/popper.min.js') }}"></script>
</body>
</html>